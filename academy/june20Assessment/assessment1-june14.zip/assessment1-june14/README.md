# Assessment

Welcome to your first assessment of the semester. Feel free to use any online resource but don't copy/paste answers to each other or if you find something similar online. You will have 90 minutes to complete this assessment.

## Starting

1. **Important:** Fork this repository to your own Github user account
2. Clone your forked repo to your local machine
5. To run the tests, cd into the `01_oo_js` directory and type `testem`

This works just like the Test First JavaScript exercises that we've done - reverse engineer the test, write code to make the tests.

## Submitting

When time is complete or when you finish the code, commit the changes to the git repository using the command: `git commit -am "submitting assessment"` Then, do two things:

1. Push your repository back to your own personal fork of using `git push`.
2. Zip up your entire assessment directory on your local machine and email it to instructors+assessment@fullstackacademy.com
