var Element = function (attributes, children){
  this.attributes = attributes || {};
  this.children = children || [];
  this.type = undefined;
}

Element.prototype.appendChild = function(child) {
  if(this.type === "paragraph" && child.type === "div"){
    return undefined;
  }
  this.children.push(child);
};

var Div = function(attributes, children){
  // what is the diff between two forms? same?
  // Element.prototype.constructor.call(this, attributes, children);
  Element.call(this, attributes, children);
  this.type = "div";

  if (typeof this.attributes.id != "undefined"){
    this.id = this.attributes.id;
  }
  if (typeof this.attributes.className != "undefined"){
    this.className = this.attributes.className;
  }

}

var Paragraph = function(attributes, children){
  Element.call(this, attributes, children);
  this.type = "paragraph";

  if (typeof this.attributes.id != "undefined"){
    this.id = this.attributes.id;
  }
  if (typeof this.attributes.className != "undefined"){
    this.className = this.attributes.className;
  }

  //remove if its a div.
  for(var i = 0; i<this.children.length;i++){
    if(this.children[i].type === "div")
      this.children.splice(i);
  }
};

Paragraph.prototype = new Element();
Paragraph.prototype.constructor = Paragraph;

Div.prototype = new Element();
Div.prototype.constructor = Div;

