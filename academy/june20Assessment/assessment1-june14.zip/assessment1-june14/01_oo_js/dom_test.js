/**
 * In this part, we are going to model two basic HTML elements, DIV and P
 * using Object-Oriented JavaScript and Prototypical Inheritance.
 * We have a parent class "Element" and two sub-classes of Element 
 * called Div and Paragraph.
 * As you may have guessed, Div and Paragraph should inherit from Element
 *
 * All of these objects can be constructed with "attributes" and "children"
 * where attributes is an object and children is an array of other divs 
 * and paragraphs
 * 
 * !!!!! Remember, Think Prototypal Inheritance !!!!!
 */

describe('Element', function () {
  it('should have a constructor function that takes two parameters', function () {
    var elem = new Element({style:"color: black"}, ["Dark Text"]);
    expect(elem.children).toEqual(["Dark Text"]);
    expect(elem.attributes).toEqual({ style: "color: black" });
  });

  it('should set defaults in the constructor', function () {
    var elem = new Element();
    expect(elem.children).toEqual([]);
    expect(elem.attributes).toEqual({});
  });

  it('should not have a type defined', function () {
    var elem = new Element();
    expect(elem.type).toEqual(undefined);
  });
});


describe('Div (inherits from Element)', function () {
  it('should inherit from Element', function () {
    var div = new Div();
    expect(div instanceof Element).toEqual(true);
    expect(div instanceof Div).toEqual(true);
  });

  it('should call Elements constructor function', function () {
    // this test makes sure that Element (the function) is called
    var cSpy = spyOn(window, 'Element').andCallThrough();
    var div = new Div();
    expect(cSpy).toHaveBeenCalled();
    expect(div.children).toEqual([]);
  });

  it('should use its arguments', function (done) {
    var div = new Div({style:"color"});
    console.log(div.attributes);
    expect(div.attributes.style).toEqual("color");
  });

  it('should have a id property if there was a id in attributes', function () {
    var div = new Div({id: "topBar"});
    expect(div.id).toEqual("topBar");
  });

  it('should have a className property if there was a className in attributes', function () {
    var div = new Div({className: "heading"});
    expect(div.className).toEqual("heading");
  });

  it('should have a property type equal to div', function () {
    var div = new Div();
    expect(div.type).toEqual("div");
  });

});


describe('Paragraph (inherits from Element)', function () {
  it('should inherit from Element', function () {
    var paragraph = new Paragraph();
    expect(paragraph instanceof Element).toEqual(true);
  });

  it('should call Elements constructor function', function () {
    // this test makes sure that Element (the function) is called
    var cSpy = spyOn(window, 'Element').andCallThrough();
    var paragraph = new Paragraph();
    expect(cSpy).toHaveBeenCalled();
    expect(paragraph.children).toEqual([]);
  });

  it('should have a id property if there was a id in attributes', function () {
    var paragraph = new Paragraph({id: "topBar"});
    expect(paragraph.id).toEqual("topBar");
  });

  it('should have a className property if there was a className in attributes', function () {
    var paragraph = new Paragraph({className: "heading"});
    expect(paragraph.className).toEqual("heading");
  });

  it('should have a property type equal to paragraph', function () {
    var paragraph = new Paragraph();
    expect(paragraph.type).toEqual("paragraph");
  });
});



describe('Elements interacting', function () {
  it('should allow children to be appended via appendChild', function (done) {
    var p1 = new Paragraph();
    var p2 = new Paragraph();
    var p3 = new Paragraph();

    var div = new Div({}, [p1, p2]);
    div.appendChild(p3);
    expect(div.children).toEqual([p1, p2, p3]);
  });

  it('should not allow Paragraphs to contain Divs', function () {
    var div = new Div();
    var nestedP = new Paragraph();
    var p = new Paragraph({}, [nestedP, div]);
    expect(p.children).toEqual([nestedP]);
  });

  it('should not allow paragraphs to append divs', function () {
    var div = new Div();
    var p = new Paragraph();
    p.appendChild(div);
    expect(p.children).toEqual([]);
  });
});

/**
  ________   _________ _____               _____ _____  ______ _____ _____ _______
 |  ____\ \ / /__   __|  __ \     /\      / ____|  __ \|  ____|  __ \_   _|__   __|
 | |__   \ V /   | |  | |__) |   /  \    | |    | |__) | |__  | |  | || |    | |
 |  __|   > <    | |  |  _  /   / /\ \   | |    |  _  /|  __| | |  | || |    | |
 | |____ / . \   | |  | | \ \  / ____ \  | |____| | \ \| |____| |__| || |_   | |
 |______/_/ \_\  |_|  |_|  \_\/_/    \_\  \_____|_|  \_\______|_____/_____|  |_|

  These are a bit more difficult so come back to these if you have time.

 */

describe('Elements and search', function () {
  var p1, p2, p3, p4, div1;

  beforeEach(function() {
    p1 = new Paragraph({id: 1, className: "heading"});
    p2 = new Paragraph({id: 2, className: "content"});
    p3 = new Paragraph({id: 3, className: "quote"});
    p4 = new Paragraph({id: 4, className: "quote"});
    div1 = new Div({}, []);

  });


  it('should be able to find nested children by Id ', function () {
    p1.appendChild(p2);
    p2.appendChild(p3);
    p3.appendChild(p4);
    // similar to <p id="1><p id="2"><p id="3"><p id="4"></p></p></p></p>
    expect(p1.findElementById("4")).toEqual(p4);
  });

  it('should be able to find nested children by className and return a flat array of elements ', function () {
    div1.appendChild(p1);
    p1.appendChild(p2);
    p2.appendChild(p3);
    p3.appendChild(p4);
    // similar to <div><p id="1><p id="2"><p id="3"><p id="4"></p></p></p></p></div>
    expect(div1.getElementsByClass("quote")).toEqual([p3, p4]);
  });
});




