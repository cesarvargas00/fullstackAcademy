Use testem to run the files in this directory and make sure the tests are passing
